<script setup>
import { ref, onMounted } from "vue";
import router from "../router";

</script>

<template>
  <main>
    <div class="container my-5">
      <h1>Home</h1>
      <div class="my-5">
        <h2>Les derniers films</h2>
        <div class="row my-2">
        </div>
      </div>
      <hr class="border-bottom border-dark my-2 fw-bold">
      <div class="my-5">
        <h2>Les derniers acteurs</h2>
        <div class="row my-2">
        </div>
      </div>
    </div>
  </main>
</template>
